This compressed archive contains the following folders:


en.stsw-link009 - USB Driver for Windows

en.stsw-link007_v3-10-3 - Firmware update file for the Nucleo and integrated debugger.
                          This fixes an issue in previous versions that cause the debugger
                          to reset the serial port.

To install:

1. If using Windows, before you connect the Nucleo board (no harm done if you connect it first, but it will not work correctly), run the stlink_winusb_install.bat file in the en.stsw-link009 folder. 

Then connect the Nuceo board via a USB cable. This is usually a USB male A to male "mini" cable. You should then see the Nucleo board listed in the Device Manager 3 times. It will install the device as a portable drive under "Portable Devices" as "NOD_411RE" or similar, it will list "STMicroelectronics STLink Virtual COM Port (COMx) under "Ports (COM & LPT), and it will install "ST-Link Debug under "Universal Serial Bus devices". Proceed to step 2.

Other platforms should be able to plug the board to the computer with a USB cable and proceed to step two.

2. Update the firmware. Instructions are in the readme.txt file found in the en.stsw-link007_v3-10-3 folder. Windows users will go to the en.stsw-link007_v3-10-3\stsw-link007\Windows folder and run the "ST-LinkUpgrade.exe" program and follow the prompts.

All platforms (including Windows) can run the "STLinkUpgrade.jar" file in the "en.stsw-link007_v3-10-3\stsw-link007\AllPlatforms" folder.

3. Install Visual Studio Code with the PlatformIO plugin.

For more information, see https://dcc-ex.com/reference/hardware/microcontrollers/nucleo.html